def foo():
    print('Hello from the inside')